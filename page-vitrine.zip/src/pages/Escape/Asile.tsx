function AsilePage() {
    return (
        <div className="session-page">
            <h1>Asile 666</h1>
            <p>
                Survivrez-vous à l’asile psychiatrique oublié où d’anciens patients hantent encore les couloirs ? Frissons garantis.
            </p>
            <p><strong>Tarif :</strong> 18€/joueur</p>
        </div>
    );
}

export default AsilePage;
