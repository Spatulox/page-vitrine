function ManoirPage() {
    return (
        <div className="session-page">
            <h1>Le Manoir du Diable</h1>
            <p>
                Infiltrez un manoir abandonné et affrontez les forces maléfiques qui y résident. Chaque porte peut être la dernière…
            </p>
            <p><strong>Tarif :</strong> 16€/joueur</p>
        </div>
    );
}

export default ManoirPage;
